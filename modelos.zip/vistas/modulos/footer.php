<footer class="main-footer">

    <strong>Copyright &copy; 2017 <a href="https://www.tutorialesatualcance.com" target="_blank_">Tutoriales a tu alcance</a></strong>

    Todos los derechos reservados
</footer>